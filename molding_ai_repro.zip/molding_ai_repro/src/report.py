from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .constants import DISPLAY_PATHS, HISTORICAL_INPUT_AUDIT, LOSS_MODES

LOSS_LABELS = {"bce": "BCE", "cost": "Cost", "focal": "Focal", "cost_focal": "Cost + Focal"}
METRICS = [("F1_score", "F1"), ("AP", "AP"), ("AUC_ROC", "ROC-AUC")]


def summarize(metrics: pd.DataFrame):
    grouped = metrics.groupby(["product", "encoder", "path", "loss"], sort=False)
    rows = []
    for keys, frame in grouped:
        product, encoder, path, loss = keys
        row = dict(product=product, encoder=encoder, path=path, loss=loss)
        for metric, _ in METRICS:
            row[f"{metric}_mean"] = frame[metric].mean()
            row[f"{metric}_std"] = frame[metric].std(ddof=1)
        row["val_AP_mean"] = frame.val_AP.mean()
        row["val_AP_std"] = frame.val_AP.std(ddof=1)
        rows.append(row)
    return pd.DataFrame(rows)


def _heatmap(ax, frame, encoder, metric, title):
    values = np.full((len(DISPLAY_PATHS), len(LOSS_MODES)), np.nan)
    labels = np.empty_like(values, dtype=object)
    for i, path in enumerate(DISPLAY_PATHS):
        for j, loss in enumerate(LOSS_MODES):
            r = frame[(frame["encoder"] == encoder) & (frame["path"] == path) & (frame["loss"] == loss)]
            if len(r) == 1:
                mean = float(r.iloc[0][f"{metric}_mean"])
                sd = float(r.iloc[0][f"{metric}_std"])
                values[i, j] = mean
                labels[i, j] = f"{mean:.3f}\n±{sd:.3f}"
            else:
                labels[i, j] = ""
    im = ax.imshow(values, aspect="auto", vmin=0, vmax=1 if metric == "AUC_ROC" else None, cmap="YlGnBu")
    ax.set_title(title, fontsize=11, weight="bold")
    ax.set_xticks(range(len(LOSS_MODES)), [LOSS_LABELS[x] for x in LOSS_MODES], rotation=20, ha="right")
    ax.set_yticks(range(len(DISPLAY_PATHS)), DISPLAY_PATHS, fontsize=8)
    for i in range(values.shape[0]):
        for j in range(values.shape[1]):
            if np.isfinite(values[i, j]):
                rgba = im.cmap(im.norm(values[i, j]))
                luminance = 0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]
                ax.text(j, i, labels[i, j], ha="center", va="center", fontsize=7,
                        color="black" if luminance > .55 else "white")
    plt.colorbar(im, ax=ax, fraction=.046, pad=.04)


def plot_encoder_comparison(summary: pd.DataFrame, product: str, out_file: Path):
    product_frame = summary[summary["product"] == product]
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    for row, encoder in enumerate(["MLP (previous)", "FT-Transformer"]):
        for col, (metric, label) in enumerate(METRICS):
            _heatmap(axes[row, col], product_frame, encoder, metric, f"{encoder} — {label}")
            if col > 0:
                axes[row, col].set_yticklabels([])
    fig.suptitle(
        f"{product.upper()} — Same preprocessing / MLP vs FT-Transformer SCARF encoder\n"
        "Seeds 42–44: mean ± SD; columns = joint encoder fine-tuning loss",
        fontsize=14,
    )
    fig.tight_layout(rect=(0, 0, 1, .94))
    fig.savefig(out_file, dpi=160, bbox_inches="tight")
    plt.close(fig)


def compare_reference(summary: pd.DataFrame, reference_csv: Path | None):
    if reference_csv is None or not reference_csv.exists():
        return {"reference_available": False}
    ref = pd.read_csv(reference_csv)
    current = summary[summary["product"].eq("cn7")].copy()
    keys = ["encoder", "path", "loss"]
    merged = ref.merge(current, on=keys, suffixes=("_ref", "_run"), how="left")
    diffs = {}
    for metric in ["F1_score", "AP", "AUC_ROC"]:
        for stat in ["mean", "std"]:
            a = merged[f"{metric}_{stat}_ref"]
            b = merged[f"{metric}_{stat}_run"]
            diffs[f"{metric}_{stat}_max_abs_diff"] = float((a - b).abs().max()) if b.notna().any() else None
    return {
        "reference_available": True,
        "rows_expected": len(ref), "rows_matched": int(merged[f"AP_mean_run"].notna().sum()),
        **diffs,
    }


def generate_reports(metrics: pd.DataFrame, preprocess_summary: pd.DataFrame, output_root: Path,
                     reference_csv: Path | None = None):
    summary = summarize(metrics)
    summary.to_csv(output_root / "summary_mean_sd.csv", index=False)
    for product in sorted(summary["product"].unique()):
        plot_encoder_comparison(summary, product, output_root / f"{product}_encoder_comparison.png")

    input_checks = []
    for row in preprocess_summary.to_dict("records"):
        product = row["product"]
        target = HISTORICAL_INPUT_AUDIT[product]
        current = {
            "selected_rows": int(row["selected_rows"]),
            "overlap_rows_removed": int(row["overlap_rows_removed"]),
            "duplicate_rows_removed": int(row["duplicate_rows_removed"]),
            "ssl_train": int(row["ssl_train"]), "ssl_val": int(row["ssl_val"]),
            "labeled_train": int(row["labeled_train"]), "labeled_val": int(row["labeled_val"]),
            "labeled_test": int(row["labeled_test"]),
        }
        input_checks.append(dict(product=product, matches=(current == target), current=current, historical=target))

    report = {
        "historical_upstream_inputs_match": all(x["matches"] for x in input_checks),
        "input_checks": input_checks,
        "metric_reference_check": compare_reference(summary, reference_csv),
        "interpretation": (
            "Exact historical metric reproduction is meaningful only when historical_upstream_inputs_match is true "
            "and package versions match the original run."
        ),
    }
    (output_root / "reproduction_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return summary, report
