from __future__ import annotations

import copy
import json
import re
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
from imblearn.over_sampling import ADASYN, SMOTE

from .constants import FOLLOWUP_MODELS, LOSS_MODES, MODEL_SEEDS, SEED
from .models import (
    SYNTH_WEIGHT, evaluate_scores, finetune_joint, fit_followup, followup_scores,
    joint_scores, pretrain_scarf, standardize_encoder_outputs,
)
from .preprocess import add_physical_features


def _slug(text: str):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_")


def augment_training(d: dict, out_dir: Path):
    """Train-only SMOTE/ADASYN augmentation from the supplied MLP notebook."""
    train = d["parts"][0]
    y0 = d["y"][0]
    base = d["base_features"]
    source_X = d["base_pp"].transform(train[base]).astype(np.float32)
    n_bad = int(y0.sum())
    extra = int(d["target_n"])
    if n_bad < 2 or extra != n_bad:
        raise AssertionError("Historical augmentation expects target_n == original train defects")
    n_ada = int(np.floor(extra * .25 + .5))
    blocks, methods = [], []
    rng = np.random.default_rng(SEED)
    for method, count in ((SMOTE, extra - n_ada), (ADASYN, n_ada)):
        if count == 0:
            continue
        neighbor_kw = {"k_neighbors" if method is SMOTE else "n_neighbors": min(3, n_bad - 1)}
        sampler = method(
            sampling_strategy={1: n_bad + max(4 * count, n_bad)},
            random_state=SEED, **neighbor_kw,
        )
        pool = sampler.fit_resample(source_X, y0)[0][len(source_X):].astype(np.float32)
        unique = ~pd.DataFrame(np.vstack([source_X] + blocks + [pool])).round(8).duplicated().to_numpy()
        pool = pool[unique[-len(pool):]]
        if len(pool) < count:
            raise RuntimeError("Not enough unique synthetic candidates")
        blocks.append(pool[rng.permutation(len(pool))[:count]])
        methods.extend([method.__name__] * count)
    physical_base = d["base_pp"].named_steps["standardscaler"].inverse_transform(np.vstack(blocks))
    synthetic = add_physical_features(pd.DataFrame(physical_base, columns=base))
    X_new = d["pp"].transform(synthetic[d["features"]]).astype(np.float32)
    Xa = np.vstack([d["X"][0], X_new])
    ya = np.r_[y0, np.ones(extra, dtype=int)]
    weights = np.r_[np.ones(len(y0)), np.full(extra, SYNTH_WEIGHT)].astype(np.float32)
    manifest = pd.DataFrame(dict(
        source=np.where(y0 == 1, "original_bad", "original_good").tolist() + methods,
        shot_id=list(d["train_ids"]) + [None] * extra,
        label=ya, weight=weights,
    ))
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest.to_csv(out_dir / "classifier_training_manifest.csv", index=False)
    np.savez_compressed(out_dir / "classifier_training_arrays.npz", X=Xa, y=ya, weight=weights)
    return Xa, ya, weights


def _save_predictions(d: dict, row: dict, scores: np.ndarray, out_dir: Path):
    pred = scores >= row["threshold"]
    name = _slug(f"{row['encoder']}_{row['loss']}_{row['path']}_{row['seed']}")
    pd.DataFrame(dict(
        shot_id=d["test_ids"], y_true=d["y"][2], score=scores,
        prediction=pred.astype(int),
    )).to_csv(out_dir / f"{name}_test_predictions.csv", index=False)


def train_encoder_benchmark(d: dict, encoder_kind: str, out_dir: Path,
                            seeds=MODEL_SEEDS, losses=LOSS_MODES,
                            ssl_max_epochs=None, finetune_max_epochs=None,
                            followup_epochs=None, save_models=True):
    encoder_label = "MLP (previous)" if encoder_kind == "mlp" else "FT-Transformer"
    out_dir.mkdir(parents=True, exist_ok=True)
    Xa, ya, weights = augment_training(d, out_dir)
    rows = []

    def record(row, scores):
        rows.append(row)
        pd.DataFrame(rows).to_csv(out_dir / "metrics.csv", index=False)
        _save_predictions(d, row, scores, out_dir)
        print(
            f"[{d['product']} | {encoder_label}] seed={row['seed']} loss={row['loss']} "
            f"path={row['path']} AP={row['AP']:.4f} F1={row['F1_score']:.4f} AUC={row['AUC_ROC']:.4f}",
            flush=True,
        )

    for seed in seeds:
        pre_kwargs = {}
        if ssl_max_epochs is not None:
            pre_kwargs["max_epochs"] = ssl_max_epochs
        pretrained = pretrain_scarf(d, encoder_kind, seed, out_dir, **pre_kwargs)

        for mode in losses:
            ft_kwargs = {}
            if finetune_max_epochs is not None:
                ft_kwargs["max_epochs"] = finetune_max_epochs

            teacher, hist = finetune_joint(d, pretrained, Xa, ya, weights, seed, mode, head_kind="mlp", **ft_kwargs)
            hist.to_csv(out_dir / f"MLP_joint_{mode}_{seed}_history.csv", index=False)
            val_scores = joint_scores(teacher, d["X"][1])
            test_scores = joint_scores(teacher, d["X"][2])
            row = evaluate_scores(d, "MLP joint", "MLP", mode, seed, val_scores, test_scores, encoder_label)
            row["classifier_loss"] = mode
            record(row, test_scores)
            if save_models:
                torch.save(teacher.state_dict(), out_dir / f"MLP_joint_{mode}_{seed}.pt")

            teacher.eval().requires_grad_(False)
            A, V, T, scaler = standardize_encoder_outputs(d, teacher.encoder, Xa)
            if save_models:
                joblib.dump(scaler, out_dir / f"MLP_encoder_{mode}_{seed}_scaler.joblib")
            for name in FOLLOWUP_MODELS:
                epochs = followup_epochs if followup_epochs is not None else 100
                model = fit_followup(name, A, ya, weights, V, d["y"][1], seed, epochs=epochs)
                pv, pt = followup_scores(model, V), followup_scores(model, T)
                path = f"{name} follow-up"
                row = evaluate_scores(d, path, name, mode, seed, pv, pt, encoder_label)
                row["classifier_loss"] = "cost_focal" if name in ("SingleCNN", "ResidualMLP") else "cost"
                record(row, pt)
                if save_models:
                    if isinstance(model, torch.nn.Module):
                        torch.save(model.state_dict(), out_dir / f"{_slug(path)}_{mode}_{seed}.pt")
                    else:
                        joblib.dump(model, out_dir / f"{_slug(path)}_{mode}_{seed}.joblib")

            residual, rhist = finetune_joint(
                d, pretrained, Xa, ya, weights, seed, mode, head_kind="residual", **ft_kwargs
            )
            rhist.to_csv(out_dir / f"ResidualMLP_joint_{mode}_{seed}_history.csv", index=False)
            pv, pt = joint_scores(residual, d["X"][1]), joint_scores(residual, d["X"][2])
            row = evaluate_scores(d, "ResidualMLP joint", "ResidualMLP", mode, seed, pv, pt, encoder_label)
            row["classifier_loss"] = mode
            record(row, pt)
            if save_models:
                torch.save(residual.state_dict(), out_dir / f"ResidualMLP_joint_{mode}_{seed}.pt")

    metrics = pd.DataFrame(rows)
    expected = len(tuple(seeds)) * len(tuple(losses)) * 8
    if len(metrics) != expected:
        raise AssertionError(f"Expected {expected} evaluations, got {len(metrics)}")
    return metrics


def run_training(bundles: dict, output_root: Path, products=("cn7", "rg3"),
                 encoders=("mlp", "ft_transformer"), seeds=MODEL_SEEDS, losses=LOSS_MODES,
                 ssl_max_epochs=None, finetune_max_epochs=None, followup_epochs=None,
                 save_models=True):
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    if hasattr(torch.backends, "mha") and hasattr(torch.backends.mha, "set_fastpath_enabled"):
        torch.backends.mha.set_fastpath_enabled(False)
    all_metrics = []
    for product in products:
        for encoder in encoders:
            edir = output_root / product / encoder
            metrics = train_encoder_benchmark(
                bundles[product], encoder, edir, seeds=seeds, losses=losses,
                ssl_max_epochs=ssl_max_epochs, finetune_max_epochs=finetune_max_epochs,
                followup_epochs=followup_epochs, save_models=save_models,
            )
            all_metrics.append(metrics)
    combined = pd.concat(all_metrics, ignore_index=True)
    combined.to_csv(output_root / "all_metrics.csv", index=False)
    config = dict(
        products=list(products), encoders=list(encoders), seeds=list(seeds), losses=list(losses),
        deterministic_algorithms=True, cpu_threads=2,
        note="Loss columns are the joint encoder fine-tuning loss; follow-up classifiers retain notebook-specific fixed losses.",
    )
    (output_root / "training_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    return combined
