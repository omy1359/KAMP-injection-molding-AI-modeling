from __future__ import annotations

SEED = 42
MODEL_SEEDS = (42, 43, 44)
TEST_SHARE = 0.20
VAL_SHARE_OF_REMAINDER = 0.25
SSL_VAL_SHARE = 0.10
TOP_PERCENTILE = 10.0
KNN_NEIGHBORS = 5

DERIVED = [
    "R_flow", "L_stroke", "Delta_T_feed", "Delta_T_mold",
    "I_ext_thermal", "eta_apparent", "t_eff_pack",
]

FEATURES_30 = [
    "Injection_Time", "Filling_Time", "Plasticizing_Time", "Cycle_Time",
    "Clamp_Close_Time", "Cushion_Position", "Plasticizing_Position",
    "Max_Injection_Speed", "Max_Screw_RPM", "Average_Screw_RPM",
    "Max_Injection_Pressure", "Max_Switch_Over_Pressure", "Max_Back_Pressure",
    "Average_Back_Pressure", "Barrel_Temperature_1", "Barrel_Temperature_2",
    "Barrel_Temperature_3", "Barrel_Temperature_4", "Barrel_Temperature_5",
    "Barrel_Temperature_6", "Hopper_Temperature", "Mold_Temperature_3",
    "Mold_Temperature_4", *DERIVED,
]

ZERO_REGIME = [
    "Max_Screw_RPM", "Average_Screw_RPM", "Average_Back_Pressure",
    "Barrel_Temperature_1", "Mold_Temperature_3", "Mold_Temperature_4",
]

LOSS_MODES = ("bce", "cost", "focal", "cost_focal")
FOLLOWUP_MODELS = ("SVM", "XGBoost", "LightGBM", "CatBoost", "SingleCNN", "ResidualMLP")
DISPLAY_PATHS = (
    "MLP joint", "SVM follow-up", "XGBoost follow-up", "LightGBM follow-up",
    "CatBoost follow-up", "SingleCNN follow-up", "ResidualMLP follow-up",
    "ResidualMLP joint",
)

# Historical notebook audit. These are used only for validation, never to alter data.
HISTORICAL_INPUT_AUDIT = {
    "cn7": dict(selected_rows=3524, overlap_rows_removed=0, duplicate_rows_removed=1,
                ssl_train=3170, ssl_val=353, labeled_train=363, labeled_val=121, labeled_test=122),
    "rg3": dict(selected_rows=3596, overlap_rows_removed=200, duplicate_rows_removed=1677,
                ssl_train=1547, ssl_val=172, labeled_train=354, labeled_val=118, labeled_test=119),
}
