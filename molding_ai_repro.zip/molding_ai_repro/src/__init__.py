"""Portable injection-molding SCARF benchmark pipeline."""
