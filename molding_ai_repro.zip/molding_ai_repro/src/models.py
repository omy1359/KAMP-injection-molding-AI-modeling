from __future__ import annotations

import copy
import math
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import average_precision_score, confusion_matrix, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

from .constants import SEED

WIDTH = 256
SSL_BATCH = 128
SCARF_CORRUPTION = 0.6
TEMPERATURE = 1.0
SSL_MAX_EPOCHS = 1000
FINETUNE_MAX_EPOCHS = 200
FOLLOWUP_EPOCHS = 100
PATIENCE = 3
STATIC_VALIDATION_PASSES = 10
MAX_FPR = 0.05
GAMMA = 2.0
COST_POWER = 0.5
SYNTH_WEIGHT = 0.5


def mlp_encoder(d: int) -> nn.Module:
    layers = []
    for _ in range(4):
        layers += [nn.Linear(d, WIDTH), nn.ReLU()]
        d = WIDTH
    return nn.Sequential(*layers)


FT_CONFIG = dict(token_width=64, blocks=2, heads=4, ffn_width=128,
                 attention_dropout=0.1, ffn_dropout=0.1, output_width=256)


class FTBlock(nn.Module):
    def __init__(self, first=False):
        super().__init__()
        d = FT_CONFIG["token_width"]
        self.attention_norm = nn.Identity() if first else nn.LayerNorm(d)
        self.attention = nn.MultiheadAttention(
            d, FT_CONFIG["heads"], dropout=FT_CONFIG["attention_dropout"], batch_first=True
        )
        self.ffn_norm = nn.LayerNorm(d)
        self.inward = nn.Linear(d, 2 * FT_CONFIG["ffn_width"])
        self.dropout = nn.Dropout(FT_CONFIG["ffn_dropout"])
        self.outward = nn.Linear(FT_CONFIG["ffn_width"], d)

    def forward(self, x, last=False):
        h = self.attention_norm(x)
        q = h[:, :1] if last else h
        a = self.attention(q, h, h, need_weights=False)[0]
        x = (x[:, :1] if last else x) + a
        u, gate = self.inward(self.ffn_norm(x)).chunk(2, dim=-1)
        return x + self.outward(self.dropout(u * gate.relu()))


class FTEncoder(nn.Module):
    def __init__(self, n_features: int):
        super().__init__()
        d = FT_CONFIG["token_width"]
        self.feature_weight = nn.Parameter(torch.empty(n_features, d))
        self.feature_bias = nn.Parameter(torch.empty(n_features, d))
        self.cls = nn.Parameter(torch.empty(1, 1, d))
        for value in (self.feature_weight, self.feature_bias, self.cls):
            nn.init.uniform_(value, -1 / math.sqrt(d), 1 / math.sqrt(d))
        self.blocks = nn.ModuleList([FTBlock(first=i == 0) for i in range(FT_CONFIG["blocks"])])
        self.output = nn.Sequential(nn.LayerNorm(d), nn.ReLU(), nn.Linear(d, WIDTH))

    def forward(self, x):
        tokens = x.unsqueeze(-1) * self.feature_weight + self.feature_bias
        tokens = torch.cat([self.cls.expand(len(x), -1, -1), tokens], dim=1)
        for i, block in enumerate(self.blocks):
            tokens = block(tokens, last=i == len(self.blocks) - 1)
        return self.output(tokens[:, 0])


def make_encoder(kind: str, n_features: int) -> nn.Module:
    if kind == "mlp":
        return mlp_encoder(n_features)
    if kind == "ft_transformer":
        return FTEncoder(n_features)
    raise ValueError(kind)


class PaperSCARF(nn.Module):
    def __init__(self, encoder: nn.Module, donors: torch.Tensor):
        super().__init__()
        self.encoder = encoder
        self.pretraining_head = nn.Sequential(
            nn.Linear(WIDTH, WIDTH), nn.ReLU(), nn.Linear(WIDTH, WIDTH)
        )
        self.corruption_rate = SCARF_CORRUPTION
        self.register_buffer("donors", donors, persistent=False)

    def corrupt(self, x, generator):
        n, d = x.shape
        q = int(self.corruption_rate * d)
        columns = torch.rand(n, d, generator=generator).argsort(dim=1)[:, :q]
        mask = torch.zeros(n, d, dtype=torch.bool).scatter_(1, columns, True)
        rows = torch.randint(len(self.donors), (n, d), generator=generator)
        replacements = self.donors[rows, torch.arange(d)]
        return torch.where(mask, replacements, x), mask

    def forward(self, x, changed):
        return self.pretraining_head(self.encoder(x)), self.pretraining_head(self.encoder(changed))


def paper_infonce(z, changed, temperature=TEMPERATURE):
    logits = F.normalize(z, dim=1) @ F.normalize(changed, dim=1).T / temperature
    return F.cross_entropy(logits, torch.arange(len(z), device=z.device)) - np.log(len(z))


def batches(order, size=SSL_BATCH):
    chunks = list(order.split(size))
    if len(chunks) > 1 and len(chunks[-1]) == 1:
        chunks[-2] = torch.cat([chunks[-2], chunks[-1]])
        chunks.pop()
    return chunks


def pretrain_scarf(d: dict, encoder_kind: str, seed: int, output_dir: Path,
                    max_epochs: int = SSL_MAX_EPOCHS, patience: int = PATIENCE):
    torch.manual_seed(seed)
    g = torch.Generator().manual_seed(seed)
    x = torch.as_tensor(d["pre_X"], dtype=torch.float32)
    v = torch.as_tensor(d["pre_val"], dtype=torch.float32)
    net = PaperSCARF(make_encoder(encoder_kind, x.shape[1]), x)
    opt = torch.optim.Adam(net.parameters(), lr=0.001)
    vg = torch.Generator().manual_seed(SEED + 2000)
    fixed = []
    for _ in range(STATIC_VALIDATION_PASSES):
        changed, _ = net.corrupt(v, vg)
        for idx in batches(torch.randperm(len(v), generator=vg)):
            fixed.append((v[idx], changed[idx]))
    best, state, stale, history = float("inf"), None, 0, []
    for epoch in range(max_epochs):
        net.train()
        total = 0.0
        for idx in batches(torch.randperm(len(x), generator=g)):
            changed, _ = net.corrupt(x[idx], g)
            loss = paper_infonce(*net(x[idx], changed))
            opt.zero_grad(); loss.backward(); opt.step()
            total += float(loss.detach()) * len(idx)
        net.eval()
        with torch.no_grad():
            val = sum(float(paper_infonce(*net(a, b))) * len(a) for a, b in fixed) / sum(len(a) for a, _ in fixed)
        history.append(dict(epoch=epoch + 1, train_loss=total / len(x), val_loss=val))
        if val < best:
            best, state, stale = val, copy.deepcopy(net.state_dict()), 0
        else:
            stale += 1
        if stale >= patience:
            break
    net.load_state_dict(state)
    output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(net.encoder.state_dict(), output_dir / f"scarf_encoder_{encoder_kind}_{seed}.pt")
    pd.DataFrame(history).to_csv(output_dir / f"scarf_ssl_{encoder_kind}_{seed}.csv", index=False)
    return copy.deepcopy(net.encoder).eval().requires_grad_(False)


class ResidualBlock(nn.Module):
    def __init__(self, width=64, dropout=0.1):
        super().__init__()
        self.branch = nn.Sequential(
            nn.LayerNorm(width), nn.Linear(width, width), nn.ReLU(),
            nn.Dropout(dropout), nn.Linear(width, width),
        )

    def forward(self, x):
        return x + self.branch(x)


class ResidualMLP(nn.Module):
    def __init__(self, d, outputs=1):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(d, 64), nn.ReLU(), ResidualBlock(), ResidualBlock(),
            nn.LayerNorm(64), nn.Linear(64, outputs),
        )
        self.outputs = outputs

    def forward(self, x):
        z = self.layers(x)
        return z.squeeze(1) if self.outputs == 1 else z


class JointClassifier(nn.Module):
    def __init__(self, encoder: nn.Module, head_kind="mlp"):
        super().__init__()
        self.encoder = encoder
        if head_kind == "mlp":
            self.head = nn.Sequential(nn.Linear(WIDTH, WIDTH), nn.ReLU(), nn.Linear(WIDTH, 2))
        elif head_kind == "residual":
            self.head = ResidualMLP(WIDTH, outputs=2)
        else:
            raise ValueError(head_kind)

    def forward(self, x):
        return self.head(self.encoder(x))


def supervised_loss(logits, target, weights, mode, cost):
    ce = F.cross_entropy(logits, target, reduction="none")
    if mode in ("focal", "cost_focal"):
        ce = ce * (-torch.expm1(-ce)).pow(GAMMA)
    if mode in ("cost", "cost_focal"):
        ce = ce * torch.where(target == 1, cost, 1.0)
    return (ce * weights).sum() / weights.sum()


def joint_scores(model: nn.Module, X: np.ndarray):
    model.eval()
    with torch.no_grad():
        return model(torch.as_tensor(X, dtype=torch.float32)).softmax(1)[:, 1].numpy()


def encoded(encoder: nn.Module, X: np.ndarray):
    encoder.eval()
    with torch.no_grad():
        return encoder(torch.as_tensor(X, dtype=torch.float32)).numpy()


def finetune_joint(d: dict, pretrained: nn.Module, X: np.ndarray, y: np.ndarray,
                   weights: np.ndarray, seed: int, mode: str, head_kind="mlp",
                   max_epochs: int = FINETUNE_MAX_EPOCHS, patience: int = PATIENCE):
    torch.manual_seed(seed)
    model = JointClassifier(copy.deepcopy(pretrained), head_kind=head_kind)
    model.requires_grad_(True)
    opt = torch.optim.Adam(model.parameters(), lr=0.001)
    x = torch.tensor(X, dtype=torch.float32)
    t = torch.tensor(y, dtype=torch.long)
    w = torch.tensor(weights, dtype=torch.float32)
    g = torch.Generator().manual_seed(seed + 8000)
    Xv, yv = d["X"][1], d["y"][1]
    cost = float((weights[y == 0].sum() / weights[y == 1].sum()) ** COST_POWER)
    best, state, stale, history = float("inf"), None, 0, []
    for epoch in range(max_epochs):
        model.train(); total = 0.0
        for idx in batches(torch.randperm(len(x), generator=g)):
            loss = supervised_loss(model(x[idx]), t[idx], w[idx], mode, cost)
            opt.zero_grad(); loss.backward(); opt.step()
            total += float(loss.detach()) * len(idx)
        score = joint_scores(model, Xv)
        ap = average_precision_score(yv, score)
        criterion = -ap
        history.append(dict(epoch=epoch + 1, train_loss=total / len(x), val_AP=ap, selection="AP"))
        if criterion < best:
            best, state, stale = criterion, copy.deepcopy(model.state_dict()), 0
        else:
            stale += 1
        if stale >= patience:
            break
    model.load_state_dict(state)
    return model.eval(), pd.DataFrame(history)


class SingleCNN(nn.Sequential):
    def __init__(self, d):
        super().__init__(nn.Conv1d(1, 16, 3, padding=1), nn.ReLU(), nn.Flatten(), nn.Linear(16 * d, 1))

    def forward(self, x):
        return super().forward(x.unsqueeze(1)).squeeze(1)


def followup_scores(model, X):
    if isinstance(model, nn.Module):
        model.eval()
        with torch.no_grad():
            return model(torch.tensor(X, dtype=torch.float32)).sigmoid().numpy()
    if isinstance(model, SVC):
        return model.decision_function(X)
    return model.predict_proba(X)[:, 1]


def fit_followup(name, X, y, confidence, Xv, yv, seed, epochs: int = FOLLOWUP_EPOCHS):
    cost = float((confidence[y == 0].sum() / confidence[y == 1].sum()) ** COST_POWER)
    if name == "SVM":
        return SVC(C=1.0, kernel="rbf", gamma="scale", class_weight={0: 1.0, 1: cost}).fit(
            X, y, sample_weight=confidence
        )
    if name == "XGBoost":
        return XGBClassifier(
            n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8,
            colsample_bytree=0.8, min_child_weight=2, reg_lambda=1,
            objective="binary:logistic", tree_method="hist", scale_pos_weight=cost,
            random_state=seed, n_jobs=2,
        ).fit(X, y, sample_weight=confidence)
    if name == "LightGBM":
        return LGBMClassifier(
            n_estimators=200, max_depth=3, num_leaves=7, min_child_samples=10,
            learning_rate=0.05, class_weight={0: 1.0, 1: cost}, objective="binary",
            verbosity=-1, random_state=seed, n_jobs=2,
        ).fit(X, y, sample_weight=confidence)
    if name == "CatBoost":
        return CatBoostClassifier(
            iterations=200, depth=3, learning_rate=0.05, loss_function="Logloss",
            class_weights=[1.0, cost], random_seed=seed, thread_count=2,
            verbose=False, allow_writing_files=False,
        ).fit(X, y, sample_weight=confidence)
    torch.manual_seed(seed)
    model = SingleCNN(X.shape[1]) if name == "SingleCNN" else ResidualMLP(X.shape[1])
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    x, t, c = [torch.tensor(a, dtype=torch.float32) for a in [X, y, confidence]]
    best, state = -1.0, None
    for _ in range(epochs):
        model.train()
        bce = F.binary_cross_entropy_with_logits(model(x), t, reduction="none")
        loss = (bce * (-torch.expm1(-bce)).pow(GAMMA) * torch.where(t == 1, cost, 1.0) * c).sum() / c.sum()
        opt.zero_grad(); loss.backward(); opt.step()
        ap = average_precision_score(yv, followup_scores(model, Xv))
        if ap > best:
            best, state = ap, copy.deepcopy(model.state_dict())
    model.load_state_dict(state)
    return model


def standardize_encoder_outputs(d: dict, encoder: nn.Module, Xa: np.ndarray):
    scaler = StandardScaler().fit(encoded(encoder, d["X"][0]))
    A, V, T = [
        scaler.transform(encoded(encoder, a)).astype(np.float32)
        for a in [Xa, d["X"][1], d["X"][2]]
    ]
    return A, V, T, scaler


def evaluate_scores(d: dict, path: str, model_name: str, loss: str, seed: int,
                    val_scores: np.ndarray, test_scores: np.ndarray, encoder_label: str):
    yv, yt = d["y"][1:]
    negatives = np.sort(val_scores[yv == 0])
    k = int(np.floor(MAX_FPR * len(negatives)))
    threshold = float(np.nextafter(negatives[len(negatives) - k - 1], np.array(np.inf, dtype=negatives.dtype)))
    pred = test_scores >= threshold
    tn, fp, fn, tp = confusion_matrix(yt, pred, labels=[0, 1]).ravel()
    return dict(
        product=d["product"], encoder=encoder_label, loss=loss, path=path, model=model_name, seed=seed,
        AP=average_precision_score(yt, test_scores), F1_score=f1_score(yt, pred, zero_division=0),
        AUC_ROC=roc_auc_score(yt, test_scores), val_AP=average_precision_score(yv, val_scores),
        val_FPR=float((val_scores[yv == 0] >= threshold).mean()), threshold=threshold,
        TN=int(tn), FP=int(fp), FN=int(fn), TP=int(tp),
        actual_positive=int(tp + fn), actual_negative=int(tn + fp),
    )


def smoke_models():
    torch.manual_seed(123)
    x = torch.randn(8, 30)
    donors = torch.randn(32, 30)
    for kind in ("mlp", "ft_transformer"):
        enc = make_encoder(kind, 30)
        assert enc(x).shape == (8, 256)
        net = PaperSCARF(enc, donors)
        changed, mask = net.corrupt(x, torch.Generator().manual_seed(42))
        assert mask.sum(1).eq(18).all()
        loss = paper_infonce(*net(x, changed))
        loss.backward()
        assert torch.isfinite(loss)
    for outputs in (1, 2):
        m = ResidualMLP(256, outputs)
        z = m(torch.randn(8, 256))
        assert z.shape == ((8,) if outputs == 1 else (8, 2))
    return True
