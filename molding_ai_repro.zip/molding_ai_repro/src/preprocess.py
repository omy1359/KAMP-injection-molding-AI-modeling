from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .constants import (
    DERIVED, FEATURES_30, HISTORICAL_INPUT_AUDIT, KNN_NEIGHBORS, SEED,
    SSL_VAL_SHARE, TEST_SHARE, TOP_PERCENTILE, VAL_SHARE_OF_REMAINDER, ZERO_REGIME,
)
from .data import (
    collapse_verified_pairs, load_normalized_product, load_raw_labeled_product,
    load_raw_unlabeled_rows, load_selection_unlabeled, sensor_groups,
)

EPS = 1e-6


def add_physical_features(frame: pd.DataFrame):
    """Seven physical derivatives used by the supervised notebook."""
    x = frame.copy()
    for c in [
        "Max_Injection_Pressure", "Max_Injection_Speed", "Plasticizing_Position",
        "Cushion_Position", "Barrel_Temperature_5", "Hopper_Temperature",
        "Mold_Temperature_3", "Mold_Temperature_4", "Filling_Time", "Injection_Time",
    ]:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    speed = x["Max_Injection_Speed"].where(x["Max_Injection_Speed"] > 0)
    x["R_flow"] = x["Max_Injection_Pressure"] / (speed + EPS)
    x["L_stroke"] = x["Plasticizing_Position"] - x["Cushion_Position"]
    x["Delta_T_feed"] = x["Barrel_Temperature_5"] - x["Hopper_Temperature"]
    x["Delta_T_mold"] = x["Mold_Temperature_4"] - x["Mold_Temperature_3"]
    x["I_ext_thermal"] = (x["Mold_Temperature_3"] + x["Mold_Temperature_4"]) / 2 - x["Hopper_Temperature"]
    x["eta_apparent"] = x["Max_Injection_Pressure"] * x["Filling_Time"] / (speed + EPS)
    x["t_eff_pack"] = x["Injection_Time"] - x["Filling_Time"]
    return x


def add_selection_features(frame: pd.DataFrame):
    """Exact derivative formulas from extract_top10_to_excel.py."""
    x = frame.copy()
    x["R_flow"] = x["Max_Injection_Pressure"] / (x["Max_Injection_Speed"].abs() + 1e-6)
    x["L_stroke"] = x["Plasticizing_Position"] - x["Cushion_Position"]
    x["Delta_T_feed"] = x["Barrel_Temperature_5"] - x["Hopper_Temperature"]
    x["Delta_T_mold"] = (x["Mold_Temperature_4"] - x["Mold_Temperature_3"]).abs()
    x["I_ext_thermal"] = (x["Mold_Temperature_3"] + x["Mold_Temperature_4"]) / 2 - x["Hopper_Temperature"]
    x["eta_apparent"] = x["Max_Injection_Pressure"] * x["Filling_Time"] / (x["Max_Injection_Speed"].abs() + 1e-6)
    x["t_eff_pack"] = x["Injection_Time"] - x["Filling_Time"]
    return x


def build_supervised_bundle(dataset_zip: Path, product: str):
    """Stages 1-3: product selection, verified shot merge, 30 physical features, group split."""
    product = product.lower()
    norm_labeled, _, sensors = load_normalized_product(dataset_zip, product)
    raw = load_raw_labeled_product(dataset_zip, product)
    labeled = add_physical_features(collapse_verified_pairs(raw, sensors, product, "labeled"))

    labeled["sensor_group"] = sensor_groups(labeled, sensors)
    group_y = labeled.groupby("sensor_group").PassOrFail.max()
    fit_groups, test_groups = train_test_split(
        group_y.index, test_size=TEST_SHARE, stratify=group_y, random_state=SEED
    )
    train_groups, val_groups = train_test_split(
        fit_groups, test_size=VAL_SHARE_OF_REMAINDER,
        stratify=group_y.loc[fit_groups], random_state=SEED + 1,
    )
    parts = [labeled[labeled.sensor_group.isin(g)].copy() for g in (train_groups, val_groups, test_groups)]
    if sum(len(p) for p in parts) != len(labeled):
        raise AssertionError("Labeled split lost rows")

    good_train = parts[0].loc[parts[0].PassOrFail.eq(0)]
    base_features = [
        c for c in sensors if c != "Clamp_Open_Position" and good_train[c].nunique(dropna=True) > 1
    ]
    features = base_features + DERIVED
    if features != FEATURES_30:
        raise AssertionError(f"Expected the historical 30 features, got {features}")

    cycle = pd.to_numeric(good_train.Cycle_Time, errors="coerce")
    cycle = cycle[cycle > 0]
    cycle_upper = float(cycle.mean() + 3 * cycle.std(ddof=0))

    def clean(frame):
        f = frame.copy()
        v = pd.to_numeric(f.Cycle_Time, errors="coerce")
        f["Cycle_Time"] = v.where(v > 0).clip(upper=cycle_upper)
        return f

    parts = [clean(p) for p in parts]
    good_train = parts[0].loc[parts[0].PassOrFail.eq(0)]
    base_pp = make_pipeline(SimpleImputer(strategy="median"), StandardScaler()).fit(good_train[base_features])
    pp = make_pipeline(SimpleImputer(strategy="median"), StandardScaler()).fit(good_train[features])
    X = [pp.transform(p[features]).astype(np.float32) for p in parts]
    y = [p.PassOrFail.to_numpy(dtype=int) for p in parts]

    return dict(
        product=product, sensors=sensors, labeled_shots=labeled, parts=parts,
        base_features=base_features, features=features, base_pp=base_pp, pp=pp,
        X=X, y=y, train_ids=parts[0].shot_id.to_numpy(), test_ids=parts[2].shot_id.to_numpy(),
        cycle_upper=cycle_upper, target_n=int(y[0].sum()),
        raw_labeled_rows=len(raw), labeled_shots_count=len(labeled),
    )


def _normalized_train_shots(dataset_zip: Path, product: str, supervised: dict):
    """Map current shot split onto the normalized moldset coordinates."""
    norm_labeled, _, _ = load_normalized_product(dataset_zip, product)
    lookup = norm_labeled.set_index("Unnamed: 0")
    train = supervised["parts"][0]
    ids = train.source_row_ids.str.split(",").str[0].astype(int)
    mapped = lookup.loc[ids].reset_index(drop=False)
    mapped["PassOrFail"] = train.PassOrFail.to_numpy()
    return add_selection_features(mapped)


def fallback_selection_reference(dataset_zip: Path, product: str, supervised: dict):
    """Portable reconstruction when the historical split workbook is absent.

    The historical notebooks consumed an external CN7_RG3_shot_preprocessed_splits*.xlsx
    that is not contained in Dataset_Molding.zip. The most faithful reconstructable
    fallback is therefore the current shot-level *supervised* train split after its
    train-good imputation/standardization. This is deterministic and uses only the
    supplied archive, but is explicitly marked as a reconstructed input.
    """
    out = pd.DataFrame(supervised["X"][0], columns=FEATURES_30)
    out["PassOrFail"] = supervised["y"][0]
    return out, "reconstructed_supervised_train_from_dataset_zip"


def selection_reference(dataset_zip: Path, product: str, supervised: dict, split_workbook: Path | None):
    if split_workbook is not None:
        sheet = f"{product.upper()}_Train"
        ref = pd.read_excel(split_workbook, sheet_name=sheet)
        missing = [c for c in FEATURES_30 if c not in ref]
        if missing:
            raise ValueError(f"{sheet} missing columns: {missing}")
        return ref, f"historical_workbook:{split_workbook.name}:{sheet}"
    return fallback_selection_reference(dataset_zip, product, supervised)


def select_indomain(dataset_zip: Path, product: str, reference_train: pd.DataFrame, out_dir: Path, selection_source_dir: Path | None = None):
    """Stage 4: exact 30-D kNN top-10% selection from extract_top10_to_excel.py."""
    unlabeled, unlabeled_source = load_selection_unlabeled(dataset_zip, product, selection_source_dir)
    target = add_selection_features(unlabeled)
    scaler = StandardScaler()
    X_ref = scaler.fit_transform(reference_train[FEATURES_30])
    X_u = scaler.transform(target[FEATURES_30])
    knn = NearestNeighbors(n_neighbors=KNN_NEIGHBORS, metric="euclidean", n_jobs=-1).fit(X_ref)
    mean_distance = knn.kneighbors(X_u)[0].mean(axis=1)
    cutoff = float(np.percentile(mean_distance, TOP_PERCENTILE))
    mask = mean_distance <= cutoff
    selected = target.loc[mask].copy()
    selected.insert(0, "source_row_id", selected["Unnamed: 0"].astype(int).to_numpy())
    selected["knn_distance"] = mean_distance[mask]
    out_dir.mkdir(parents=True, exist_ok=True)
    selected.to_csv(out_dir / f"{product}_selected_top10.csv", index=False)
    return selected, dict(
        source_rows=len(target), reference_rows=len(reference_train), selected_rows=len(selected),
        cutoff=cutoff, min_distance=float(mean_distance.min()), max_distance=float(mean_distance.max()),
        unlabeled_selection_source=unlabeled_source,
    )


def renormalize_selected(selected: pd.DataFrame, product: str, out_dir: Path):
    """Exact re-centering/re-scaling from renormalize_selected_unlabeled.py."""
    scaler = StandardScaler()
    z = scaler.fit_transform(selected[FEATURES_30])
    ready = pd.DataFrame(z, columns=FEATURES_30)
    ready["knn_distance"] = selected.knn_distance.to_numpy()
    ready.to_csv(out_dir / f"moldset_{product}_unlabeled_final_scarf_ready.csv", index=False)
    return ready


def _canonical_raw(frame: pd.DataFrame, cols: list[str]):
    values = frame[cols].astype(np.float32).astype(np.float64)
    return sensor_groups(values, cols)


def build_ssl_split(dataset_zip: Path, product: str, supervised: dict, selected: pd.DataFrame, ready: pd.DataFrame, out_dir: Path):
    """Remove labeled overlap and duplicate raw sensor groups, then 90/10 SSL split."""
    selected_ids = selected.source_row_id.astype(int).to_numpy()
    raw_u, product_order = load_raw_unlabeled_rows(dataset_zip, product, selected_ids)
    raw_u = raw_u.loc[selected_ids].copy()
    groups = _canonical_raw(raw_u, supervised["base_features"]).to_numpy()
    label_groups = set(_canonical_raw(supervised["labeled_shots"], supervised["base_features"]))
    order_map = {int(v): i for i, v in enumerate(product_order.to_numpy())}
    manifest = pd.DataFrame({
        "csv_row": np.arange(len(selected)), "source_row_id": selected_ids,
        "sensor_group": groups, "source_order": [order_map[int(v)] for v in selected_ids],
    }).sort_values("source_order", kind="stable")
    overlap = manifest.sensor_group.isin(label_groups)
    manifest["excluded_labeled_overlap"] = overlap
    manifest["excluded_duplicate"] = False
    remain = manifest.loc[~overlap].copy()
    duplicates = remain.sensor_group.duplicated()
    manifest.loc[remain.index, "excluded_duplicate"] = duplicates
    remain = remain.loc[~duplicates]
    ssl_train, ssl_val = train_test_split(remain, test_size=SSL_VAL_SHARE, random_state=SEED)
    manifest["split"] = "excluded"
    manifest.loc[ssl_train.index, "split"] = "ssl_train"
    manifest.loc[ssl_val.index, "split"] = "ssl_val"
    manifest.to_csv(out_dir / f"{product}_unlabeled_splits.csv", index=False)
    U = ready.iloc[ssl_train.csv_row][FEATURES_30].to_numpy(dtype=np.float32)
    V = ready.iloc[ssl_val.csv_row][FEATURES_30].to_numpy(dtype=np.float32)
    np.savez_compressed(out_dir / f"{product}_ssl_arrays.npz", train=U, validation=V,
                        train_csv_rows=ssl_train.csv_row.to_numpy(), validation_csv_rows=ssl_val.csv_row.to_numpy())
    zero_rows = int(raw_u[ZERO_REGIME].eq(0).all(axis=1).sum())
    audit = dict(
        selected_rows=len(selected), overlap_rows_removed=int(overlap.sum()),
        duplicate_rows_removed=int(duplicates.sum()), ssl_train=len(U), ssl_val=len(V),
        raw_six_zero_rows_observed=zero_rows,
        labeled_train=len(supervised["parts"][0]), labeled_val=len(supervised["parts"][1]),
        labeled_test=len(supervised["parts"][2]),
    )
    audit["matches_historical_notebook"] = all(
        audit.get(k) == v for k, v in HISTORICAL_INPUT_AUDIT[product].items() if k in audit
    )
    return U, V, manifest, audit


def run_preprocessing(dataset_zip: Path, output_root: Path, products=("cn7", "rg3"), split_workbook: Path | None = None, selection_source_dir: Path | None = None):
    output_root.mkdir(parents=True, exist_ok=True)
    bundles = {}
    summary = []
    selected_for_excel = {}
    for product in products:
        pdir = output_root / product
        pdir.mkdir(parents=True, exist_ok=True)
        supervised = build_supervised_bundle(dataset_zip, product)
        ref, ref_source = selection_reference(dataset_zip, product, supervised, split_workbook)
        selected, sel_audit = select_indomain(dataset_zip, product, ref, pdir, selection_source_dir=selection_source_dir)
        ready = renormalize_selected(selected, product, pdir)
        U, V, manifest, ssl_audit = build_ssl_split(dataset_zip, product, supervised, selected, ready, pdir)
        supervised["pre_X"], supervised["pre_val"] = U, V
        supervised["selection_reference_source"] = ref_source
        supervised["preprocess_dir"] = pdir
        bundles[product] = supervised
        audit = dict(product=product, selection_reference_source=ref_source)
        audit.update(sel_audit)
        audit.update(ssl_audit)
        (pdir / "preprocess_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
        summary.append(audit)
        selected_for_excel[product] = selected
    pd.DataFrame(summary).to_csv(output_root / "preprocess_summary.csv", index=False)
    # Compatibility workbook corresponding to extract_top10 output, with provenance retained.
    with pd.ExcelWriter(output_root / "CN7_RG3_unlabeled_top10_indomain.xlsx", engine="openpyxl") as writer:
        pd.DataFrame(summary).to_excel(writer, sheet_name="selection_summary", index=False)
        for product, selected in selected_for_excel.items():
            selected.to_excel(writer, sheet_name=f"{product.upper()}_Unlabeled_Top10", index=False)
    return bundles, pd.DataFrame(summary)
