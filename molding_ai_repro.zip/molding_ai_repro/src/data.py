from __future__ import annotations

import zipfile
from pathlib import Path
import numpy as np
import pandas as pd


def _read_csv(z: zipfile.ZipFile, name: str, **kwargs) -> pd.DataFrame:
    return pd.read_csv(z.open(name), **kwargs)


def load_normalized_product(dataset_zip: Path, product: str):
    product = product.lower()
    with zipfile.ZipFile(dataset_zip) as z:
        labeled = _read_csv(z, f"dataset/moldset_labeled_{product}.csv")
        unlabeled = _read_csv(z, f"dataset/moldset_unlabeled_{product}.csv")
    sensors = [c for c in labeled.columns if c not in ["Unnamed: 0", "PassOrFail"]]
    return labeled, unlabeled, sensors


def load_raw_labeled_product(dataset_zip: Path, product: str):
    product = product.lower()
    with zipfile.ZipFile(dataset_zip) as z:
        index = _read_csv(z, f"dataset/moldset_labeled_{product}.csv", usecols=["Unnamed: 0", "PassOrFail"])
        raw = _read_csv(z, "dataset/labeled_data.csv", low_memory=False)
    raw.index.name = "source_row_id"
    frame = raw.loc[index["Unnamed: 0"].astype(int)].copy()
    expected = frame["PassOrFail"].map({"Y": 0, "N": 1}).to_numpy()
    if not np.array_equal(expected, index["PassOrFail"].to_numpy()):
        raise ValueError(f"{product}: raw and moldset labels disagree")
    frame["PassOrFail"] = expected
    return frame


def load_raw_unlabeled_rows(dataset_zip: Path, product: str, selected_ids=None):
    """Read only rows needed from the large raw unlabeled CSV, preserving moldset order."""
    product = product.lower()
    with zipfile.ZipFile(dataset_zip) as z:
        product_ids = _read_csv(z, f"dataset/moldset_unlabeled_{product}.csv", usecols=["Unnamed: 0"])["Unnamed: 0"].astype(int)
        wanted = set(product_ids if selected_ids is None else pd.Series(selected_ids).astype(int))
        chunks = []
        for chunk in pd.read_csv(z.open("dataset/unlabeled_data.csv"), chunksize=100_000, low_memory=False):
            chosen = chunk[chunk["Unnamed: 0"].isin(wanted)]
            if len(chosen):
                chunks.append(chosen)
    if not chunks:
        raise ValueError(f"{product}: no raw unlabeled rows found")
    frame = pd.concat(chunks).set_index("Unnamed: 0")
    order = product_ids[product_ids.isin(wanted)]
    frame = frame.loc[order].copy()
    frame.index.name = "source_row_id"
    return frame, product_ids


def load_selection_unlabeled(dataset_zip: Path, product: str, source_dir: Path | None = None):
    """Load the unlabeled table used by extract_top10_to_excel.py.

    When an external source directory is supplied, preserve the original script's
    preference for moldset_unlabeled_<product>_2.csv, then the non-_2 file.
    Otherwise use the copy bundled in Dataset_Molding.zip.
    """
    product = product.lower()
    if source_dir is not None:
        source_dir = Path(source_dir)
        for name in (f"moldset_unlabeled_{product}_2.csv", f"moldset_unlabeled_{product}.csv"):
            candidate = source_dir / name
            if candidate.exists():
                return pd.read_csv(candidate), str(candidate)
    _, unlabeled, _ = load_normalized_product(dataset_zip, product)
    return unlabeled, f"{dataset_zip.name}:dataset/moldset_unlabeled_{product}.csv"


def _side(name: pd.Series):
    return name.astype(str).str.extract(r"\b(LH|RH)\b", expand=False)


def collapse_verified_pairs(frame: pd.DataFrame, sensor_cols: list[str], product: str, kind: str):
    """Collapse only verified two-cavity LH/RH twins; preserve all non-pairs."""
    x = frame.copy()
    all_sensors = x.loc[:, "Injection_Time":].columns.tolist()
    if not set(sensor_cols).issubset(all_sensors):
        missing = set(sensor_cols) - set(all_sensors)
        raise ValueError(f"Missing sensor columns: {sorted(missing)}")
    x[all_sensors] = x[all_sensors].apply(pd.to_numeric, errors="coerce")
    x["_sensor_hash"] = pd.util.hash_pandas_object(x[all_sensors].round(8), index=False).to_numpy()
    x["_side"] = _side(x["PART_NAME"])
    x["_serial"] = pd.to_numeric(x["PART_FACT_SERIAL"], errors="coerce")
    key = ["EQUIP_CD", "TimeStamp", "_sensor_hash"]
    grouped = x.groupby(key, dropna=False, sort=False)
    valid = (
        grouped["PART_NAME"].transform("size").eq(2)
        & grouped["_side"].transform("nunique").eq(2)
        & (grouped["_serial"].transform("max") - grouped["_serial"].transform("min")).eq(1)
    )
    pair_key = pd.util.hash_pandas_object(x[key], index=False).astype(str)
    x["shot_id"] = np.where(
        valid,
        product + "_" + kind + "_pair_" + pair_key,
        product + "_" + kind + "_single_" + x.index.astype(str),
    )
    x["source_row_ids"] = x.index.astype(str)
    agg = {
        "source_row_ids": lambda s: ",".join(s),
        "TimeStamp": "first", "EQUIP_CD": "first", "PART_FACT_PLAN_DATE": "first",
        "PART_FACT_SERIAL": "min", "PART_NAME": "first", "_side": "first",
    }
    agg.update({c: "first" for c in all_sensors})
    if "PassOrFail" in x:
        agg["PassOrFail"] = "max"
    shot = x.groupby("shot_id", sort=False, as_index=False).agg(agg)
    shot["cavity_count"] = shot["source_row_ids"].str.count(",") + 1
    if not shot.cavity_count.le(2).all() or int(shot.cavity_count.sum()) != len(frame):
        raise AssertionError("Pair-collapse audit failed")
    return shot


def sensor_groups(frame: pd.DataFrame, cols: list[str]):
    return pd.util.hash_pandas_object(frame[cols].round(8), index=False).astype(str)
