"""Consolidate saved predictions at the project root without retraining."""
from __future__ import annotations

import argparse
import csv
import os
import re
import tempfile
from pathlib import Path

FIELDS = [
    "product", "encoder", "loss", "model", "path", "seed", "threshold",
    "shot_id", "y_true", "score", "prediction", "source_file",
]


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_")


def export_predictions(output_root: Path, destination: Path) -> tuple[int, int]:
    output_root, destination = Path(output_root), Path(destination)
    sources = []
    seen = set()
    for metric_file in sorted(output_root.glob("*/*/metrics.csv")):
        with metric_file.open(newline="", encoding="utf-8-sig") as handle:
            for row in csv.DictReader(handle):
                name = _slug(f"{row['encoder']}_{row['loss']}_{row['path']}_{row['seed']}")
                source = metric_file.parent / f"{name}_test_predictions.csv"
                if not source.is_file():
                    raise FileNotFoundError(source)
                if source in seen:
                    raise ValueError(f"Duplicate experiment: {source}")
                seen.add(source)
                sources.append((source, row))
    if not sources:
        raise ValueError(f"No saved test predictions found in {output_root}")

    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".predictions_", suffix=".csv", dir=destination.parent)
    count = 0
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            for source, metadata in sources:
                with source.open(newline="", encoding="utf-8-sig") as source_handle:
                    reader = csv.DictReader(source_handle)
                    if reader.fieldnames != ["shot_id", "y_true", "score", "prediction"]:
                        raise ValueError(f"Unexpected prediction columns: {source}")
                    for prediction in reader:
                        merged = {key: metadata[key] for key in FIELDS[:7]}
                        merged.update(prediction)
                        merged["source_file"] = source.relative_to(output_root).as_posix()
                        writer.writerow(merged)
                        count += 1
        os.replace(temp_name, destination)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    return count, len(sources)


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=root / "outputs" / "full_run")
    parser.add_argument("--destination", type=Path, default=root.parent / "prediction_output.csv")
    args = parser.parse_args()
    count, experiments = export_predictions(args.output, args.destination)
    print(f"Saved {args.destination}: {count} rows, {experiments} experiments")


if __name__ == "__main__":
    main()
