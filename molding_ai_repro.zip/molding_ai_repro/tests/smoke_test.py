from pathlib import Path
import tempfile
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.models import smoke_models
from src.preprocess import run_preprocessing


def main():
    root = ROOT
    assert smoke_models()
    with tempfile.TemporaryDirectory() as td:
        bundles, summary = run_preprocessing(
            root.parent / "04. Dataset_Molding.zip", Path(td), products=("cn7",), split_workbook=None
        )
        assert bundles["cn7"]["X"][0].shape[1] == 30
        assert bundles["cn7"]["pre_X"].shape[1] == 30
        assert len(summary) == 1
    print("SMOKE_TEST_OK")


if __name__ == "__main__":
    main()
