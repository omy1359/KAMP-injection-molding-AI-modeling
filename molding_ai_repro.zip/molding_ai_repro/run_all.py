from __future__ import annotations

import argparse
import platform
import sys
from pathlib import Path

import pandas as pd
import torch

from export_test_predictions import export_predictions
from src.constants import LOSS_MODES, MODEL_SEEDS
from src.models import smoke_models
from src.preprocess import run_preprocessing
from src.reference import write_cn7_reference
from src.report import generate_reports
from src.train import run_training


def parse_args():
    root = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description="End-to-end injection-molding SCARF benchmark")
    p.add_argument("--dataset", type=Path, default=root.parent / "04. Dataset_Molding.zip")
    p.add_argument("--output", type=Path, default=root / "outputs" / "full_run")
    p.add_argument("--split-workbook", type=Path, default=None,
                   help="Optional historical CN7_RG3_shot_preprocessed_splits*.xlsx for exact upstream recreation")
    p.add_argument("--selection-source-dir", type=Path, default=None,
                   help="Optional directory containing moldset_unlabeled_<product>_2.csv or .csv; preserves legacy preference")
    p.add_argument("--products", nargs="+", choices=["cn7", "rg3"], default=["cn7", "rg3"])
    p.add_argument("--encoders", nargs="+", choices=["mlp", "ft_transformer"], default=["mlp", "ft_transformer"])
    p.add_argument("--preprocess-only", action="store_true")
    p.add_argument("--quick", action="store_true", help="Fast code-path check; NOT a benchmark reproduction")
    p.add_argument("--no-save-models", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    root = Path(__file__).resolve().parent
    args.output.mkdir(parents=True, exist_ok=True)
    if not args.dataset.exists():
        raise FileNotFoundError(args.dataset)
    if args.split_workbook is not None and not args.split_workbook.exists():
        raise FileNotFoundError(args.split_workbook)

    reference_csv = root / "reference" / "cn7_historical_reference.csv"
    if not reference_csv.exists():
        write_cn7_reference(reference_csv)

    print("[1/4] model smoke test")
    smoke_models()
    print("[2/4] preprocessing")
    bundles, prep_summary = run_preprocessing(
        args.dataset, args.output / "preprocessing", products=args.products,
        split_workbook=args.split_workbook, selection_source_dir=args.selection_source_dir,
    )
    print(prep_summary[[
        "product", "selection_reference_source", "selected_rows", "overlap_rows_removed",
        "duplicate_rows_removed", "ssl_train", "ssl_val", "matches_historical_notebook",
    ]].to_string(index=False))

    if args.preprocess_only:
        print(f"Preprocessing complete: {args.output}")
        return

    print("[3/4] SCARF pretraining + supervised benchmark")
    if args.quick:
        seeds = (42,)
        losses = ("bce",)
        kwargs = dict(ssl_max_epochs=2, finetune_max_epochs=3, followup_epochs=3)
    else:
        seeds = MODEL_SEEDS
        losses = LOSS_MODES
        kwargs = {}
    metrics = run_training(
        bundles, args.output, products=args.products, encoders=args.encoders,
        seeds=seeds, losses=losses, save_models=not args.no_save_models, **kwargs,
    )

    print("[4/4] comparison report")
    summary, report = generate_reports(metrics, prep_summary, args.output, reference_csv=reference_csv)
    print(summary.head(12).round(4).to_string(index=False))
    print("historical_upstream_inputs_match =", report["historical_upstream_inputs_match"])
    print("python =", sys.version.split()[0], "platform =", platform.platform(), "torch =", torch.__version__)
    prediction_file = root.parent / "prediction_output.csv"
    count, experiments = export_predictions(args.output, prediction_file)
    print(f"Test predictions: {prediction_file} ({count} rows, {experiments} experiments)")
    print(f"Done: {args.output}")


if __name__ == "__main__":
    main()
